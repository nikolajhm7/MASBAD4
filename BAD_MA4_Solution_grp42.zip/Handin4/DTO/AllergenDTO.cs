﻿namespace Handin4.DTO
{
    public class AllergenDTO
    {
        public string? Name { get; set; }
    }
}
